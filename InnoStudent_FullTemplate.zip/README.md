# InnoStudent 🎓

InnoStudent is an Android app that empowers students to showcase, refine, and receive feedback on innovative projects.

## Features
- Firebase Authentication
- Project upload, edit, delete
- Ratings & reviews
- Profile management
- Admin project review

## Tech Stack
- Kotlin
- Android Jetpack
- Firebase (Auth, Firestore, Storage)
