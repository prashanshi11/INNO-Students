package com.yourname.innostudent.activities

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.yourname.innostudent.R

class ProjectListActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_project_list)
    }
}
